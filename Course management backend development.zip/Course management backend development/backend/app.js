const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const courseRoutes = require('./src/routes/courseRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

app.use('/api/courses', courseRoutes);

app.get('/', (req, res) => {
  res.send(`
    <h1>课程管理后台 API 服务</h1>
    <p>服务运行正常！</p>
    <p>可用接口：</p>
    <ul>
      <li><a href="/api/courses">GET /api/courses</a> - 获取所有课程</li>
    </ul>
  `);
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});