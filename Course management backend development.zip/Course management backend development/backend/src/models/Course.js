const { v4: uuidv4 } = require('uuid');

let courses = [
  {
    id: '1',
    name: '高等数学',
    description: '大学数学基础课程，涵盖微积分、极限等内容',
    instructor: '张教授',
    credit: 4,
    category: '数学',
    status: 'active',
    createdAt: new Date().toISOString()
  },
  {
    id: '2',
    name: '计算机科学导论',
    description: '计算机科学入门课程，介绍计算机基础知识',
    instructor: '李老师',
    credit: 3,
    category: '计算机',
    status: 'active',
    createdAt: new Date().toISOString()
  },
  {
    id: '3',
    name: '英语听说',
    description: '提升英语听说能力的课程',
    instructor: '王老师',
    credit: 2,
    category: '语言',
    status: 'active',
    createdAt: new Date().toISOString()
  }
];

const Course = {
  getAll: () => courses,
  
  getById: (id) => courses.find(course => course.id === id),
  
  create: (data) => {
    const newCourse = {
      id: uuidv4(),
      name: data.name,
      description: data.description,
      instructor: data.instructor,
      credit: data.credit,
      category: data.category,
      status: data.status || 'active',
      createdAt: new Date().toISOString()
    };
    courses.push(newCourse);
    return newCourse;
  },
  
  update: (id, data) => {
    const index = courses.findIndex(course => course.id === id);
    if (index === -1) return null;
    
    courses[index] = {
      ...courses[index],
      ...data
    };
    return courses[index];
  },
  
  delete: (id) => {
    const index = courses.findIndex(course => course.id === id);
    if (index === -1) return false;
    
    courses.splice(index, 1);
    return true;
  }
};

module.exports = Course;