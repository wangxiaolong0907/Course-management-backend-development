const Course = require('../models/Course');

const courseController = {
  getAllCourses: (req, res) => {
    const courses = Course.getAll();
    res.json(courses);
  },

  getCourseById: (req, res) => {
    const { id } = req.params;
    const course = Course.getById(id);
    if (!course) {
      return res.status(404).json({ message: '课程不存在' });
    }
    res.json(course);
  },

  createCourse: (req, res) => {
    const { name, description, instructor, credit, category, status } = req.body;
    
    if (!name || !description || !instructor || !credit || !category) {
      return res.status(400).json({ message: '缺少必要字段' });
    }

    const newCourse = Course.create({
      name,
      description,
      instructor,
      credit,
      category,
      status: status || 'active'
    });

    res.status(201).json(newCourse);
  },

  updateCourse: (req, res) => {
    const { id } = req.params;
    const updateData = req.body;

    const updatedCourse = Course.update(id, updateData);
    if (!updatedCourse) {
      return res.status(404).json({ message: '课程不存在' });
    }

    res.json(updatedCourse);
  },

  deleteCourse: (req, res) => {
    const { id } = req.params;
    const success = Course.delete(id);

    if (!success) {
      return res.status(404).json({ message: '课程不存在' });
    }

    res.json({ message: '课程删除成功' });
  }
};

module.exports = courseController;